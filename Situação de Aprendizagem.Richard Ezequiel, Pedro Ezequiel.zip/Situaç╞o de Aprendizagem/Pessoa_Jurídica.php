<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" type ="text/css"  href = "Style.css"> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Api receita federal</title>
</head>
<body class="pagina">
<div class="bg-primary text-white sticky-top ">
    <div class="d-flex justify-content-center">
    <div class="h1" > Cadastrar e Consultar Pessoa Jurídica</div>
    </div>
    </div>
    <div class="row">
        <div class="col-md-4">
           
        </div>
        <div class="col-md-4"><br><br>  
            <div class="form-group row">
                <div class="col-md-12">
                    <label>CNPJ</label>
                    <input type="text" onblur="checkCnpj(this.value)" class="form-control" data-mask="00.000.000/0000-00">
                </div>
            </div>
            <br>
            <div class="form-group row">
                <div class="col-md-6">
                    <label>Razão Social</label>
                    <input type="text" id="razaosocial" class="form-control">
                </div>
                <div class="col-md-6">
                    <label>Fantasia</label>
                    <input type="text" id="fantasia" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-6">
                    <label>Logradouro</label>
                    <input type="text" id="logradouro" class="form-control">
                </div>
                <div class="col-md-6">
                    <label>Número</label>
                    <input type="text" id="numero" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-6">
                    <label>Município</label>
                    <input type="text" id="municipio" class="form-control">
                </div>
                <div class="col-md-6">
                    <label>UF</label>
                    <input type="text" id="uf" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-6">
                    <label>CEP</label>
                    <input type="text" id="cep" class="form-control">
                </div>
                <div class="col-md-6">
                    <label>ENDEREÇO ELETRÔNICO</label>
                    <input type="text" id="enderecoele" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-6">
                    <label>	PORTE</label>
                    <input type="text" id=	"porte" class="form-control">
                </div>
                <div class="col-md-6">
                    <label>Complemento</label>
                    <input type="text" id="complemento" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-6">
                    <label>Abertura</label>
                    <input type="text" id="Abertura" class="form-control">
                </div>
                <div class="col-md-6">
                    <label>Atividade Principal</label>
                    <input type="text" id="atividade_principal" class="form-control">
                </div>
            </div>
            <br>
            <div class="form-group row">
                <div class="col-md-6">
                    <button class="btn btn-primary">Salvar</button>
                </div>
            </div>
            
        </div>
        <div class="col-md-4">
           
        </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>
  
    <script type="text/javascript">
        function checkCnpj(cnpj){
            $.ajax({
                url:    "https://www.receitaws.com.br/v1/cnpj/"+cnpj.replace(/[^0-9]/g,'')+"",
                type:   "GET",
                dataType:"jsonp",
               
                success: function( data ){
                    console.log(data);
                    if(data.nome == undefined){
                        alert(data.status + ' ' + data.message);
                    } else {
                        document.getElementById('razaosocial').value = data.nome;
                        document.getElementById('fantasia').value = data.fantasia;
                        document.getElementById('logradouro').value = data.logradouro;
                        document.getElementById('numero').value = data.numero;
                        document.getElementById('municipio').value = data.municipio;
                        document.getElementById('uf').value = data.uf;
                        document.getElementById('cep').value = data.cep;
                        document.getElementById('enderecoele').value = data.enderecoele;
                        document.getElementById('porte').value = data.porte;
                        document.getElementById('complemento').value = data.complemento;
                        document.getElementById('Abertura').value = data.Abertura;
                        document.getElementById('atividade_principal').value = data.atividade_principal;
                    }
                }
            });
        }
    </script>
  </body>
</body>
</html>