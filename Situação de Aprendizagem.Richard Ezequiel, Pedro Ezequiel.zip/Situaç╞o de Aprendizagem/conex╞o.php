<?php
$host = "localhost:3308";
$usuario = "root";
$senha = "";
$bd ="cadastro";

$conexão =mysqli_connect ($host, $usuario, $senha,$bd);

if (!$conexão){
   die ("Falha na coneção:".mysqli_connect_error());
    
}

?>
