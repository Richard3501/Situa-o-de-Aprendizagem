<?php include("conexão.php")  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" type ="text/css"  href = "Style.css">  
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">   
    <title>Login</title>
</head>

<body class="pagina">
    <header>

            <div class="container " id="nav-container">
                <nav class="navbar navbar-expand-lg fixed-top">
                  
                    <a href="#" class="navbar-brand">
                        <img src="Receita.jpg">
                        <br>
                    </a>
                    <h1>Receita Federal</h1>
                    <br>
                    <br>
                <div class="navbar-nav">
               
                <h2> <li> <a class="BTPJ" href="Pessoa_Jurídica.php" id="PJ">Pessoa Jurídica</a></li> </h2> 
                
                
                <h2> <li> <a class="BTPF" href="Pessoa_Física.php" id="PF">Pessoa Física</a></li> </h2> 
               
                </div>

                   </div>
           
         </div>
    </div>
    </nav>
           
   


    <div class="d-flex justify-content-center">
         
<br>

</div>

   <br>
   <br>
   
   <br>
   <br>
   
   <br>
   <br>
   

   <div class="bg-primary text-white sticky-top ">
<div class="form-row justify-content-center">
<div class="d-flex justify-content-center">

        <main class="shadow-lg py-50 px-md-5 mt-4 mb-4 bg-white text-dark rounded border">
            <!--    <main class="d-flex shadow-lg justify-content-center rounded border">-->
                
        <form action="index.php" method="post">
        <div class="form-group justify-content-center">
            <h1 class="text-center">Login</h1>
        </div>
            
            <div class="form-group justify-content-center">
   
            <label for="email">E-mail</label>
                <input type="email" class="form-control" name="email" id="email" value="<?= isset($email) ? $email : 'email' ?>">
            </div>
            <div class="form-group justify-content-center">
                <label for="senha">Senha</label>
                <input type="password" name="senha" class="form-control" id="senha" value="<?= isset($senha) ? $senha : 'validaCampoEmBranco' ?>">
            </div>
            <div class="form-group justify-content-center">
            <input  type="submit" value="Entrar" class="btn btn-primary">
            </div>
         
        </form>
    </main>
</div>

</div>
   </div>



</body >
</html>