<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" type ="text/css"  href = "Style.css"> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Pessoa Física</title>
</head>
<body class="pagina">
<?php include_once("conexão.php")  ?>
<?php
    if(isset($_POST['submit']))
    {

       
    

   $Nome = $_POST['Nome'];
   $Telefone = $_POST['Telefone'];
   $Sexo = $_POST['Sexo'];
   $Endereço = $_POST['Endereço'];
    
   $cadastro = mysqli_query($conexão,"INSERT INTO cadastro pessoa física (Nome,Telefone,Sexo,Endereço)
   VALUES('$Nome','$Telefone','$Sexo','$Endereço')") ;

    }

   
?>

    <div class="bg-primary text-white sticky-top ">
    <div class="d-flex justify-content-center">
    <div class="h1" > Cadastrar e Consultar Pessoa Fisíca</div>
    </div>
    </div>
   
</div>
<br>
<hr>
<br>
<Center>


<form method="POST" action="Pessoa_Física.php" >



<label>Nome:</label>
<input type="text" name="Nome"id="Nome">

<label>Telefone:</label>
<input type="text"name="Telefone"id="Telefone">

<label>Sexo:</label>
<input type="text" name="Sexo" id="Sexo">

<label>Endereço:</label>
<input type="text" name="Endereço" id="Endereço">
<br>
<br>
<br>
<br>


<input type="submit" name="submit"  id= Consultar value="Consultar">


<input type="submit" name="submit" id= Cadastrar value="Cadastrar">

<hr>
</form>


<footer class = "bg-primary fixed-bottom text-center text-white">
    <p></p>
</footer>
</Center>




</body>
</html>